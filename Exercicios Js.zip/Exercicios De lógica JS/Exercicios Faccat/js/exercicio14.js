//Ler um valor e escrever a mensagem É MAIOR QUE 10! se o valor lido for maior que 10, caso 
//contrário escrever NÃO É MAIOR QUE 10!

let valor = prompt("Insira um valor");

if (valor > 10) 
    console.log(`O valor ${valor} é maior que 10`);
else if(valor = 10)
    console.log(`O valor ${valor} é igual a 10`);
else
console.log(`O valor ${valor} é menor que 10`);
