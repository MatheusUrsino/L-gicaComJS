//Ler um valor e escrever se é positivo ou negativo (considere o valor zero como positivo)

let valor = prompt("insira um valor");

if (valor >= 0) console.log("positivo");
else console.log("negativo");
