let numeroTabuada = parseInt(prompt("Escreva um numero e lhe mostrarei a tabuada do mesmo"))

for (let contadora = 1; contadora < 11; contadora++) {
   console.log(`${numeroTabuada} X ${contadora} = ${numeroTabuada * contadora}`)
    
}