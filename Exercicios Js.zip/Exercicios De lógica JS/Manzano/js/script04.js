diaDaSemana = parseInt(prompt("Digite um numero: "));

switch (diaDaSemana) 
{

  case 1:
    alert("Domingo");
    break;

  case 2:
    alert("Segunda");
    break;

  case 3:
    alert("terça");
    break;

  case 4:
    alert("quarta");
    break;

  case 5:
    alert("quinta");
    break;

  case 6:
    alert("Sexta");
    break;

  case 7:
    alert("Sabado");
    break;
  default: 
    alert("Não há dia da semana correspondente a este numero.")
    break;
}
