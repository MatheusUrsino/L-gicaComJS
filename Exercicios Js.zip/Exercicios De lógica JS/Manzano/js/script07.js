//Apresentar os quadrados dos números inteiros de 15 a 200.

let contadora = 15;

do
{
    console.log(`O quadrado do numero ${contadora} é igual a: ${contadora * contadora}`)
    contadora++
}while (contadora < 201)