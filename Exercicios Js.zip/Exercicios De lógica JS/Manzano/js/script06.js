let numero = parseInt(prompt("digite um numero: "))
let contadora = 1

while(contadora < 11)
{
    console.log(`${numero} X ${contadora} = ${numero * contadora}`)
    contadora++
}
