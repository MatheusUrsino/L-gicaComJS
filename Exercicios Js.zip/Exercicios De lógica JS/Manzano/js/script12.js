let numero = 1
let acumuladora = 0;
for (numero; numero < 101; numero++) {
    console.log(acumuladora += numero)
    
}