const pessoas = ["jailsão da massa", "Matheus", "Chagas"];

let texto = "";
for (let x of pessoas) {
    texto += x + " | ";
}
console.log(texto)