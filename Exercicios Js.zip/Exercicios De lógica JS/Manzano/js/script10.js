for (let index = 15; index < 201; index++) {
    console.log(`O quadrado de ${index} é: ${index * index}`)
}