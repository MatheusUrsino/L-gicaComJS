for (let contadora = 0; contadora < 10; contadora++) {
   console.log(contadora)
}