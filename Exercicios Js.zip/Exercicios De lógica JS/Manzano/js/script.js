let tempCelsius = parseFloat(prompt("Digite a temperatura em graus Celsius: "));
let tempFahrenheit = (9 * tempCelsius + 160) / 5;


  alert("A temperatura em graus Fahrenheit é: " + tempFahrenheit +"°F");