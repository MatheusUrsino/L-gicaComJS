function changeText()
{
    document.getElementById('teste').innerHTML = "Eu avisei que mudaria!";
}