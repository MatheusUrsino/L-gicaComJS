function changeText()
{
    document.write(15+16 + "<br \n>");
    
    document.write(15+20);
}