let numero01;
let numero02;
let resultado;

function soma() {
  alert("Vamos Somar!");
  numero01 = prompt("Digite Aqui");
  numero02 = prompt("Digite outro numero Aqui");
  resultado = parseInt(numero01) + parseInt(numero02);
  alert("A Soma do numero " + numero01 +" e " + numero02 + " é igual a: " + resultado);
}