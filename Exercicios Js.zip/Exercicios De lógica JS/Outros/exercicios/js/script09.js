let numero1
let numero2

function alertVoid()
{
alert("Boa tarde")
numero1: prompt("Digite um numero")
numero2: prompt("Digite outro numero")
alert(numero1 + numero2)
}