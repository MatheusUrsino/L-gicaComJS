let userAndPassWord = ["", ""]
let verificar = [false,false]



function validarUser() 
{



  while (!verificar[0]) 
    {
    userAndPassWord[0] = prompt("Insira seu nome de usuário (Deve conter no mínimo 1 letra)");
    if (userAndPassWord[0].length > 0) {
      verificar[0] = true;
    } else {
      alert("Usuário incorreto, tente novamente");
    }
  }

  return userAndPassWord[0];
}

function validarSenha(usuario) 
{


  while (!verificar[1]) 
    {
    userAndPassWord[1] = prompt("Insira sua senha (Deve conter no máximo 8 caracteres e não pode ser o nome do usuário)");

    if (userAndPassWord[1].length <= 8 && userAndPassWord[1] !== usuario) {
      verificar[1] = true;
    } else {
      alert("Senha incorreta, tente novamente");
    }
  }

  return userAndPassWord[1];
}

// Validar nome de usuário e senha
userAndPassWord[0] = validarUser();
userAndPassWord[1] = validarSenha(userAndPassWord[0]);

alert("Cadastro realizado com sucesso!");