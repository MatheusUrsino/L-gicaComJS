//Função Somar
function somar(x1, x2) {
  return x1 + x2;
}

//Função subtrair
function subtrair(x1, x2) {
  if (x1 > x2) return x1 - x2;
  else return x2 - x1;
}

//Função dividir
function dividir(x1, x2) {
  return x1 / x2;
}

//Função multiplicar
function multiplicar(x1, x2) {
  return x1 * x2;
}

//variaveis para coletar os dois valores que o usuario deseja
let PodeNumeroNegativo = prompt("Você deseja receber resultados com numeros negativos? S/N");

let num1 = parseInt(prompt("insira um valor inteiro aqui"));
let num2 = parseInt(prompt("insira outro valor inteiro aqui"));

//solicita ao usuário para escolher qual função vai utilizar
let escolha = parseInt(prompt("escolha uma operação: \n 1 - soma \n 2 - subtração \n 3 - divisão \n 4 - multiplicação"));

//Variavel utilizada para armazenar o resultado da função
let resultado = 0;

//Possiveis caminhos que o usuário pode seguir
switch (escolha) {


  case 1:
    resultado = num1 + num2;
    document.getElementById("resultado").innerHTML = `${num1} + ${num2} = ${resultado}`;
    break;

  case 2:
    if (PodeNumeroNegativo == "S" || PodeNumeroNegativo == "s") {
      resultado = num1 - num2;
      document.getElementById("resultado").innerHTML = `${num1} - ${num2} = ${resultado}`;
    } 
    else if (PodeNumeroNegativo == "N" || PodeNumeroNegativo == "n") 
    {
      if (num1 > num2) 
      {
        resultado = num1 - num2;
        document.getElementById(
          "resultado"
        ).innerHTML = `${num1} - ${num2} = ${resultado}`;
      } 
      else if (num2 > num1) 
      {
        resultado = num2 - num1;
        document.getElementById("resultado").innerHTML = `${num2} - ${num1} = ${resultado}`;
      }
    }
    break;


  case 3:
      resultado = num1 / num2;
      document.getElementById("resultado").innerHTML = `${num1} / ${num2} = ${resultado}`;
    break;


  case 4:
      resultado = num1 * num2;
      document.getElementById("resultado").innerHTML = `${num1} X ${num2} = ${resultado}`;
    break;


  default: 
    document.getElementById("resultado").innerHTML = `Valores incorretos.`;
}
