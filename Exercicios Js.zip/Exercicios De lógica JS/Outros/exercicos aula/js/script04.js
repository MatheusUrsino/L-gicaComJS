function multiplicar(x1, x2) {
  return x1 * x2;
}

let resultado = multiplicar(3, 3);
document.getElementById("demo").innerHTML = resultado;
