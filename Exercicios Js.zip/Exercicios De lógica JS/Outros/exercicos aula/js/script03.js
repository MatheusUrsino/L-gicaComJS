document.getElementById("demo1").innerHTML = Math.round(4.6);

document.getElementById("demo2").innerHTML = parseInt(4.6)

document.getElementById("demo3").innerHTML = Math.trunc(4.6);
