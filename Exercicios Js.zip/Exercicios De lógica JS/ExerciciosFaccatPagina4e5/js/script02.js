// ) Escreva um algoritmo para ler um valor (do teclado) e escrever (na tela) o seu sucessor

let valor = parseInt(prompt("Digite um valor:"));
let sucessor = valor + 1;
alert(`O sucessor de ${valor} é ${sucessor}.`);

