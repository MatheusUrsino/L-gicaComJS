// //12) Escreva um algoritmo para ler uma temperatura em graus Fahrenheit, calcular e escrever o valor 
// correspondente em graus Celsius (baseado na fórmula abaixo): 
// C F - 32 
// ---------- = -----------
// 5 9 

let temperaturaFahrenheit = parseFloat(prompt("Digite a temperatura em graus Fahrenheit:"));

let temperaturaCelsius = (temperaturaFahrenheit - 32) * (5 / 9);

alert(`A temperatura em graus Celsius é ${temperaturaCelsius.toFixed(2)} °C.`);
