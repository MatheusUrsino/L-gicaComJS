let baseTriangulo = parseFloat(prompt("Digite a base do triângulo:"));
let alturaTriangulo = parseFloat(prompt("Digite a altura do triângulo:"));
let areaTriangulo = (baseTriangulo * alturaTriangulo) / 2;
alert(`A área do triângulo é ${areaTriangulo}.`);

//triangulo