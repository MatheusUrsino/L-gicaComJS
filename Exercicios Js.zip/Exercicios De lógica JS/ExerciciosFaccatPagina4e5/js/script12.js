// 11) Uma revendedora de carros usados paga a seus funcionários vendedores um salário fixo por mês, 
// mais uma comissão também fixa para cada carro vendido e mais 5% do valor das vendas por ele 
// efetuadas. Escrever um algoritmo que leia o número de carros por ele vendidos, o valor total de suas 
// vendas, o salário fixo e o valor que ele recebe por carro vendido. Calcule e escreva o salário final do 
// vendedor. 

let numeroCarrosVendidos = parseInt(prompt("Digite o número de carros vendidos:"));
let valorTotalVendas = parseFloat(prompt("Digite o valor total das vendas:"));
let salarioFixo = parseFloat(prompt("Digite o salário fixo do vendedor:"));
let comissaoPorCarro = parseFloat(prompt("Digite o valor da comissão por carro vendido:"));

let comissaoTotal = numeroCarrosVendidos * comissaoPorCarro;
let percentualVendas = valorTotalVendas * 0.05;
let salarioFinal = salarioFixo + comissaoTotal + percentualVendas;

alert(`O salário final do vendedor é R$ ${salarioFinal.toFixed(2)}.`);
