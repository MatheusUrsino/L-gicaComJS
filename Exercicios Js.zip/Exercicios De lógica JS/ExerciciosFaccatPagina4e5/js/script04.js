let raio = parseFloat(prompt("Digite o raio do círculo:"));
let areaCirculo = Math.PI * raio * raio;
alert(`A área do círculo é ${areaCirculo.toFixed(2)}.`);

//circulo