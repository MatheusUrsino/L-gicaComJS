let base = parseFloat(prompt("Digite a base do retângulo:"));
let altura = parseFloat(prompt("Digite a altura do retângulo:"));
let areaRetangulo = base * altura;
alert(`A área do retângulo é ${areaRetangulo}.`);

//retangulo