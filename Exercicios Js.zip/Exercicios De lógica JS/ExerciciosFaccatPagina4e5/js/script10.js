// 9) Escreva um algoritmo para ler o salário mensal atual de um funcionário e o percentual de reajuste. 
// Calcular e escrever o valor do novo salário

let salarioAtual = parseFloat(prompt("Digite o salário mensal atual do funcionário:"));
let percentualReajuste = parseFloat(prompt("Digite o percentual de reajuste:"));

let aumento = (salarioAtual * percentualReajuste) / 100;
let novoSalario = salarioAtual + aumento;

alert(`O novo salário é R$ ${novoSalario.toFixed(2)}.`);
