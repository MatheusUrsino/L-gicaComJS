let ladoHexagono = parseFloat(prompt("Digite o lado do hexágono:"));
let areaHexagono = ((3 * Math.sqrt(3)) / 2) * ladoHexagono * ladoHexagono;
alert(`A área do hexágono é ${areaHexagono.toFixed(2)}.`);

//hexagono