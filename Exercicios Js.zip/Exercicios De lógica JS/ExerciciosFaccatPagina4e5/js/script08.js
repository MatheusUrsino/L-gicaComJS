// 7) Faça um algoritmo que leia a idade de uma pessoa expressa em anos, meses e dias e escreva a idade 
// dessa pessoa expressa apenas em dias. Considerar ano com 365 dias e mês com 30 dias

let anos = parseInt(prompt("Digite a idade em anos:"));
let meses = parseInt(prompt("Digite a idade em meses:"));
let dias = parseInt(prompt("Digite a idade em dias:"));

let totalDias = (anos * 365) + (meses * 30) + dias;

alert(`A idade total em dias é ${totalDias}.`);
