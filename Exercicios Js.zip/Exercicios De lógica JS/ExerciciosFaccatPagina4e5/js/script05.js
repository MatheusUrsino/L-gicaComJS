let lado = parseFloat(prompt("Digite o lado do quadrado:"));
let areaQuadrado = lado * lado;
alert(`A área do quadrado é ${areaQuadrado}.`);

//quadrado