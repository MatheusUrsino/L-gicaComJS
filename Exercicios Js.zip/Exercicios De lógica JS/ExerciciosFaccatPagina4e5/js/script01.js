// ) Escreva um algoritmo para ler um valor (do teclado) e escrever (na tela) o seu antecessor. 

let valor = parseInt(prompt("Digite um valor:"))
let antecessor = valor - 1
alert(`O antecessor de ${valor} é ${antecessor}.`)